<?xml version='1.0' encoding='ASCII' ?>
<Velocity11 file='Runset_Data' md5sum='627d0e11fb86aece65f262eb334e7d88' version='1.0' >
	<Runsets >
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\illumina_spri.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='10' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='11' />
				<Parameter Name='Start_Second' Value='41' />
				<Parameter Name='State' Value='0' />
				<Parameter Name='Depend ID' Value='0' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_setup1.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='11' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='11' />
				<Parameter Name='Start_Second' Value='41' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='10' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_reaction.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='12' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='11' />
				<Parameter Name='Start_Second' Value='41' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='11' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_setup2.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='13' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='12' />
				<Parameter Name='Start_Second' Value='7' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='12' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\illumina_double-spri.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='14' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='12' />
				<Parameter Name='Start_Second' Value='42' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='13' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_setup3.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='15' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='13' />
				<Parameter Name='Start_Second' Value='9' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='14' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_reaction.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='16' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='13' />
				<Parameter Name='Start_Second' Value='40' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='15' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_setup4.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='17' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='14' />
				<Parameter Name='Start_Second' Value='47' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='16' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_ligation.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='18' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='15' />
				<Parameter Name='Start_Second' Value='4' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='17' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_setup5.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='19' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='15' />
				<Parameter Name='Start_Second' Value='21' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='18' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\illumina_spri.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='20' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='15' />
				<Parameter Name='Start_Second' Value='39' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='19' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_setup6.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='21' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='15' />
				<Parameter Name='Start_Second' Value='58' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='20' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\illumina_spri.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='22' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='16' />
				<Parameter Name='Start_Second' Value='17' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='21' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_setup7.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='23' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='16' />
				<Parameter Name='Start_Second' Value='34' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='22' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
		<Runset Name='' >
			<Parameters >
				<Parameter Name='Protocol Name' Value='C:\VWorks Workspace\Protocol Files\truseq-nano\truseq_nano_pcr.pro' />
				<Parameter Name='Runs' Value='1' />
				<Parameter Name='Protocol Notes' Value='' />
				<Parameter Name='Priority' Value='0' />
				<Parameter Name='ID' Value='24' />
				<Parameter Name='Start_Year' Value='2013' />
				<Parameter Name='Start_Month' Value='10' />
				<Parameter Name='Start_Day' Value='18' />
				<Parameter Name='Start_Hour' Value='12' />
				<Parameter Name='Start_Minute' Value='16' />
				<Parameter Name='Start_Second' Value='34' />
				<Parameter Name='State' Value='3' />
				<Parameter Name='Depend ID' Value='23' />
				<Parameter Name='Depend_Day' Value='0' />
				<Parameter Name='Depend_Hour' Value='0' />
				<Parameter Name='Depend_Minute' Value='0' />
				<Parameter Name='Depend_Second' Value='0' />
			</Parameters>
		</Runset>
	</Runsets>
</Velocity11>
